public class XmlSaveException extends Exception {
    public XmlSaveException(String message) {
        super(message);
    }

    public XmlSaveException(Throwable cause) {
        super(cause);
    }
}
