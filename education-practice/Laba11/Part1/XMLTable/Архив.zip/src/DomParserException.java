public class DomParserException extends Exception {
    DomParserException(String message) {
        super(message);
    }

    DomParserException(Throwable cause) {
        super(cause);
    }
}
